import { useParams } from "react-router-dom";
import { useContext } from "react";
import { useNavigate } from "react-router-dom";
import UserContext from "../context/UserContext";

function Dynamicdata() {

    const otherroute = useNavigate();
    const { id } = useParams();
    
    const {userdata,loading} = useContext(UserContext);
    
    const user = userdata.find((uu) => uu.id == id);

    if (loading) return <p>Loading...</p>;

    return (
        <>
            <h2>User Detail</h2>
            <p>Name: {user.name}</p>
            <p>Email: {user.email}</p>
            <p>City: {user.address?.city}</p>
            <button onClick={() => otherroute("/other-route")}>Go to list</button>
        </>
    )
}

export default Dynamicdata;